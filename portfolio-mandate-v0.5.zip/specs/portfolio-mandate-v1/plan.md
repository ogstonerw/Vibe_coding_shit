# PM-001 — План ратификации инвестиционного мандата

Статус: ACTIVE NON-CAPITAL OVERLAY для Development/Research/Replay/DRY_RUN/Paper. Реальный капитал остается BLOCKED.

## Этап 1. Зафиксировать нормативную семантику

- Утвердить лексикографический порядок целей.
- Отделить target mandate от active Phase-1 overlay.
- Утвердить закрытые enums, deny-by-default и порядок разрешения конфликтов.
- Сверить требования `PM-REQ-*` с governance policy.

Evidence: `spec.md`, requirements/quant/architecture handoffs, deep expert review.

## Этап 2. Закрыть фундаментальные решения владельца

- `PM-DEC-001` принят: вариант 3, активный некапитальный overlay.
- `PM-DEC-002` принят: двухуровневая owner approval model.
- `PM-DEC-003` concept model принят: Level A long-lived/version-bound, Level B time-boxed или single-use; численный validity profile еще блокирует real capital.
- Последовательно закрыть численный профиль `PM-DEC-003` и решения `PM-DEC-004…PM-DEC-015`.
- Для каждого решения зафиксировать область, fail-closed default, дату действия и влияние на старые evidence.
- Не объединять решения, если одно из них требует численных hard caps или расширения real scope.

Evidence: owner decision records; позднее — подписанный manifest.

## Этап 3. Завершить machine-readable contract

- Сохранить `mandate.schema.json` и `mandate.example.toml` как неавторизующий draft envelope, который может выдать только `DENY`.
- Утвердить отдельную полную ratified mandate schema только после owner decisions.
- Утвердить `owner-decision-manifest.schema.json`, canonicalization, trust root, signature verification, bounded TTL, nonce/sequence и revocation.
- Реализовать local schema validator, semantic validator, persistent version registry и policy-hash binding.
- Реализовать restrictive overlay; только отдельный authorization evaluator может выпустить short-lived `ALLOW`.

## Этап 4. Добавить детерминированные проверки

- Schema/unknown-field/status tests.
- Policy mutation/hash mismatch tests.
- Scope intersection и minimum-cap property tests.
- Stage/authority/manifest expiry/revocation tests.
- Temporal-boundary, single-use atomic reservation/consumption, commit-time revocation race и supersession rollback tests.
- Capital-book conservation и запрещенные transfers.
- RUB PnL/NAV, TWR/MWR, FX/stablecoin attribution fixtures.
- Anti-gaming, benchmark-freeze и capacity tests.
- Cross-product Paper/live capability isolation и network-spy tests.
- Typed limit dimensionality и atomic parent reservation tests.
- Account/margin/credential topology и contagion tests.
- Protective/emergency order-policy и venue-capability gates.
- Independent evidence expiry/drift и exact PnL/TWR/MWR/FX fixtures.

## Этап 5. Независимый контроль

- Requirements traceability review.
- Institutional CIO/CRO review.
- Quant methodology/model-risk review.
- Market microstructure review.
- После реализации: code, security, risk reviews и повторный deep evidence review.
- Release verifier запускается последним и не может снять проваленный gate.

## Этап 6. Связать с TB-001

- Добавить в TB-001 только те portfolio acceptance criteria, которые нужны для достоверного Paper evidence.
- Не расширять текущие venue/symbol/stage/risk permissions.
- Зафиксировать, что Paper evidence не означает Pilot authorization.

## Verification

Текущие обязательные команды:

```bash
python3 scripts/self_check.py
python3 -m unittest discover -s tests -v
```

После реализации validator должны быть добавлены formatter/linter/type/unit/property/integration commands и точные evidence paths. До этого этапа они имеют статус `PLANNED`, а не `PASS`.

## Rollback

Документ не мутируется задним числом. Ошибочная версия получает `RETIRED` или `SUPERSEDED_BY`, новая версия создается отдельным diff. Governance policies не откатываются или заменяются этим work item.
