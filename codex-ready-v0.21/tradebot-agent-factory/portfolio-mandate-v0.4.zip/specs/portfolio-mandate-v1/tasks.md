# PM-001 — Задачи и traceability

## Выполнено в текущем черновике

- [x] `PM-TASK-001` — собрать requirements и quant handoffs (`PM-REQ-001…042`, `PM-AC-001…039`).
- [x] `PM-TASK-002` — получить architecture handoff и определить source precedence, enums и overlay semantics (`PM-AC-001`, `PM-AC-002`, `PM-AC-003`, `PM-AC-004`, `PM-AC-005`, `PM-AC-006`, `PM-AC-007`, `PM-AC-008`).
- [x] `PM-TASK-003` — написать подробную главу 1 и явно оставить live/Pilot заблокированными (`PM-AC-004`, `PM-AC-006`, `PM-AC-020`).
- [x] `PM-TASK-004` — создать строго неавторизующие draft schema/example, способные вернуть только `DENY` (`PM-AC-001`, `PM-AC-003`, `PM-AC-004`, `PM-AC-021`).
- [ ] `PM-TASK-005` — после owner decisions создать полную ratified mandate schema; draft envelope не переименовывать в активную (`PM-AC-006`, `PM-AC-022`, `PM-AC-023`, `PM-AC-029`).

## Решения владельца

- [x] `PM-TASK-010` — закрыть `PM-DEC-001`: вариант 3, нормативный Development/Research/Replay/DRY_RUN/Paper overlay без real authority (`PM-AC-004`, `PM-AC-021`, `PM-AC-037`).
- [x] `PM-TASK-011` — закрыть `PM-DEC-002`: hash-bound Level A для non-capital без права post-hoc waiver и Level B signature + independent second confirmation (`PM-AC-009`, `PM-AC-010`, `PM-AC-038`, `PM-AC-039`).
- [ ] `PM-TASK-012` — закрыть `PM-DEC-003`: expiry/review/revocation/supersession (`PM-AC-010`).
- [ ] `PM-TASK-013` — закрыть `PM-DEC-004`: NAV perimeter (`PM-AC-013`, `PM-AC-014`).
- [ ] `PM-TASK-014` — закрыть `PM-DEC-005`: aggregate hard caps и reserves; требует отдельного owner-approved policy diff (`PM-AC-006`, `PM-AC-007`).
- [ ] `PM-TASK-015` — закрыть `PM-DEC-006/008`: authority и stage semantics (`PM-AC-009`, `PM-AC-011`).
- [ ] `PM-TASK-016` — закрыть `PM-DEC-009`: benchmark registry и comparative admission (`PM-AC-016`, `PM-AC-033`).
- [ ] `PM-TASK-017` — закрыть `PM-DEC-010`: distribution waterfall и treasury rules (`PM-AC-013`).
- [ ] `PM-TASK-018` — закрыть `PM-DEC-011/012`: accounting, TWR/MWR/XIRR и residual tolerance (`PM-AC-031`, `PM-AC-032`).
- [ ] `PM-TASK-019` — закрыть `PM-DEC-013/014/015`: FX valuation, statistical evidence и capacity hurdle (`PM-AC-026`, `PM-AC-034`, `PM-AC-035`, `PM-AC-036`).

## Будущая реализация contract validator

- [ ] `PM-TASK-020` — реализовать local schema плюс semantic/registry validator (`PM-AC-001`, `PM-AC-029`).
- [ ] `PM-TASK-021` — реализовать policy hash binding и mutation tests (`PM-AC-002`).
- [ ] `PM-TASK-022` — реализовать restrictive overlay/property tests (`PM-AC-003`, `PM-AC-004`, `PM-AC-005`, `PM-AC-006`, `PM-AC-007`, `PM-AC-008`).
- [ ] `PM-TASK-023` — реализовать owner manifest validation и replay protection (`PM-AC-009`, `PM-AC-010`, `PM-AC-018`, `PM-AC-030`).
- [ ] `PM-TASK-024` — реализовать authority/stage transition engine (`PM-AC-009`, `PM-AC-011`, `PM-AC-020`, `PM-AC-021`, `PM-AC-028`).
- [ ] `PM-TASK-025` — реализовать capital-book/topology ledger и transfer denylist (`PM-AC-012`, `PM-AC-013`, `PM-AC-023`).
- [ ] `PM-TASK-026` — реализовать typed aggregate reservation engine (`PM-AC-022`, `PM-AC-027`).
- [ ] `PM-TASK-027` — реализовать exact RUB accounting/TWR/MWR/FX fixtures (`PM-AC-014`, `PM-AC-015`, `PM-AC-031`, `PM-AC-032`, `PM-AC-036`).
- [ ] `PM-TASK-028` — реализовать benchmark/evidence freeze и anti-gaming gates (`PM-AC-016`, `PM-AC-017`, `PM-AC-018`, `PM-AC-033`, `PM-AC-034`, `PM-AC-035`).
- [ ] `PM-TASK-029` — реализовать capacity curve/promotion validation (`PM-AC-019`, `PM-AC-026`).
- [ ] `PM-TASK-030` — реализовать order-policy и venue-capability promotion gates (`PM-AC-024`, `PM-AC-025`).
- [ ] `PM-TASK-031` — связать TB-001 Paper evidence с применимыми portfolio AC без расширения policy (`PM-AC-020`, `PM-AC-021`).
- [ ] `PM-TASK-032` — закрыть `PM-DEC-007` и реализовать Level-B trust root, canonicalization, signature/second-factor verifier и revocation (`PM-AC-030`, `PM-AC-038`).
## Независимые reviews

- [x] `PM-TASK-040` — institutional portfolio review текущего черновика.
- [x] `PM-TASK-041` — quant methodology review текущего черновика.
- [x] `PM-TASK-042` — market microstructure review текущего черновика.
- [x] `PM-TASK-043` — исправить BLOCKER/HIGH одним writer-ом и повторить затронутые reviews.
- [ ] `PM-TASK-044` — release verification после реализации и evidence; сейчас неприменимо к live.
- [x] `PM-TASK-045` — провести targeted CIO/quant/microstructure review решения `PM-DEC-001` и границы Paper → real (`PM-AC-037`).
- [x] `PM-TASK-046` — устранить findings и завершить targeted CIO/quant/security review решения `PM-DEC-002` (`PM-AC-038`, `PM-AC-039`).
