# PM-001 — Инвестиционный мандат и цели портфеля торговых ботов

Версия документа: 0.4  
Статус документа: `TARGET + ACTIVE NON-CAPITAL OVERLAY / REAL CAPITAL BLOCKED`  
Статус реального капитала: `BLOCKED`  
Владелец: пользователь  
Базовая валюта: `RUB`  
Дата редакции: 17.07.2026

## 1. Назначение

Этот документ является первой подробной главой полного ТЗ системы торговых ботов. Он определяет, для чего существует портфель, какие цели имеют приоритет, что входит в управляемый капитал, какие рынки и горизонты относятся к целевому состоянию, кто имеет право расширять полномочия и по каким правилам оценивается результат.

Мандат не является обещанием доходности, торговой стратегией, разрешением на реальную торговлю или заменой численной risk policy. Он задает проверяемую рамку, внутри которой будут проектироваться платформа и отдельные боты.

Решения `PM-DEC-001` и `PM-DEC-002` приняты владельцем: настоящий документ обязателен для некапитального lifecycle, а подтверждения разделены на два уровня. До закрытия решений `PM-DEC-003…PM-DEC-015` документ остается `BLOCKED` для Pilot, Production и любого реального капитала. Все некапитальные стадии выполняются только в пределах действующих более узких policies.

## 2. Источники истины и разрешение конфликтов

Применяется следующий порядок приоритета:

1. `governance/approval-policy.toml` — `tradebot-factory-approvals-v1`, version `1`.
2. `governance/risk-policy.toml` — `bitget-btc-v1`, version `1`.
3. Настоящие `spec.md` и `acceptance.toml`.
4. Принятые архитектурные документы в `docs/`.
5. ТЗ конкретного бота и существующая реализация.
6. Явно маркированные предположения.

Зафиксированные на дату редакции SHA-256:

| Файл | SHA-256 |
|---|---|
| `governance/approval-policy.toml` | `9be5ef3804dd8a35681526e9b154d50c0162ba610101dcbabd00ce29996a8708` |
| `governance/risk-policy.toml` | `4f34d45ac058bec6d5ce1ecc05dc242572a917bd6e2f6769ff53b7115f4b72e8` |

Эти hashes идентифицируют рассмотренную baseline, но не заменяют вычисление hash в момент проверки. Изменение policy делает старое решение неприменимым до повторного review.

Правила конфликта:

- allowlist вычисляется как пересечение разрешенных множеств;
- максимальные лимиты вычисляются как минимум применимых потолков;
- минимальные защитные требования вычисляются как максимум применимых требований;
- разрешающие boolean объединяются логическим `AND`;
- стадия выбирается наиболее ограничительная;
- отсутствующее, неизвестное, противоречивое, просроченное или отозванное разрешение дает `DENY`;
- пустое пересечение scope дает `DENY`;
- целевая формулировка никогда не расширяет active policy.

## 3. Термины и закрытые перечисления

### 3.1. Статус объекта

Допустимы только:

- `ACTIVE` — объект используется в указанном нефинансовом lifecycle boundary; этот статус сам по себе не разрешает реальный ордер;
- `TARGET` — целевое состояние, не создающее торговых полномочий;
- `FUTURE` — будущий scope, для которого отсутствует действующая policy;
- `SHADOW_ONLY` — рассчитывается и журналируется, но не изменяет реальные полномочия или капитал;
- `BLOCKED` — запрещено до выполнения указанного gate;
- `RETIRED` — выведено из эксплуатации; статус терминален.

### 3.2. Стадия

- `RESEARCH`;
- `REPLAY`;
- `DRY_RUN`;
- `PAPER`;
- `PILOT_LIMITED_LIVE`;
- `PRODUCTION_LIVE`.

### 3.3. Книги капитала

- `RESEARCH_PAPER`;
- `PILOT`;
- `PRODUCTION`;
- `OPERATIONAL_MARGIN_RESERVE`;
- `PROTECTED_RESERVE`;
- `DISTRIBUTION_PAYABLE`.

Неизвестное значение, синоним или дополнительное поле не нормализуется «по смыслу», а отклоняется.

Lifecycle status, execution boundary и financial authority являются разными измерениями. Реальное разрешение не читается непосредственно из mandate/template. Только отдельный deterministic authorization evaluator после проверки всех policy, manifest, runtime state и evidence может выпустить короткоживущий результат `ALLOW`; любой исходный artifact, текущий пример и любая неполная комбинация дают `DENY`.

## 4. Инвестиционная цель и порядок приоритетов

Владелец выбрал смешанную модель: долгосрочный геометрический рост капитала после полных издержек сочетается с формированием периодического денежного потока. Это не две равноправные цели: они подчинены лексикографической иерархии.

### 4.1. Лексикографическая иерархия

1. **Политика, полномочия и целостность состояния.** Система действует только в разрешенном scope. Неизвестное состояние, несовпадение policy/manifest, незавершенная reconciliation или отозванное разрешение запрещают новый риск.
2. **Выживание и защита капитала.** Hard limits, риск критической потери, stressed loss, margin, концентрации и изоляция защищенного капитала имеют приоритет над результатом.
3. **Ликвидность и обязательства.** Сохраняются операционный, маржинальный, налоговый и аварийный резервы, а также способность контролируемо сократить риск в стрессе.
4. **Геометрический рост в RUB после издержек.** Оптимизируется портфельный, а не изолированный bot PnL, с учетом исполнения, финансирования, FX и stablecoin basis.
5. **Распределяемый денежный поток.** Распределяется только settled/realized/reconciled cash после выполнения резервов и high-water-mark rules.
6. **Качество evidence и эксплуатации.** Невоспроизводимый или несверяемый результат не признается даже при привлекательном PnL.

`PM-REQ-001`: нижестоящая цель не может компенсировать нарушение вышестоящей балльной оценкой, средней метрикой или решением агента.

`PM-REQ-002`: мандат не содержит гарантированной, ожидаемой или минимально обещанной доходности. Численный performance hurdle может появиться только как отдельное owner-approved решение с методологией и uncertainty.

## 5. Target mandate и действующий Phase-1 overlay

Target mandate и active overlay хранятся раздельно. Эффективное разрешение вычисляется как:

> target mandate ∩ active governance policies ∩ verified owner decision manifest ∩ current protection/runtime state.

### 5.1. Решение PM-DEC-001: активный некапитальный overlay

Владелец выбрал вариант 3. Требования этой главы обязательны для:

- проектирования и разработки;
- Research и experiment governance;
- Replay;
- DRY_RUN;
- Paper trading и формирования Paper evidence.

Нормативность означает, что ТЗ ботов, планы, acceptance contracts, тесты, отчеты и решения агентов в этих стадиях должны соответствовать этой главе либо явно фиксировать конфликт. Она не означает доступ к капиталу.

Для всех перечисленных стадий неизменно:

- `authorization_result = DENY` для реальных ордеров;
- `real_capital_authority = false`;
- `trading_endpoint_access = false`;
- execution boundary ограничен research/replay/DRY_RUN adapter/Paper simulator;
- используется только `RESEARCH_PAPER` book;
- trade-capable credential отсутствует;
- любая попытка перейти в Pilot/Production или вызвать реальный trading endpoint является нарушением mandate.

Решение записано в `decisions/PM-DEC-001.toml`. Это record некапитального governance-решения, а не owner decision manifest для реального капитала; оно не изменяет `governance/risk-policy.toml` и `governance/approval-policy.toml`.

`PM-REQ-039`: Development/Research/Replay/DRY_RUN/Paper должны применять требования и acceptance этой главы, но cross-product authorization guard обязан сохранять `DENY_REAL_ORDERS` независимо от локального lifecycle status.

### 5.2. Решение PM-DEC-002: двухуровневое подтверждение владельца

Владелец выбрал вариант 3.

**Уровень A — некапитальные решения.** Для концепции, ТЗ, Research, Replay, DRY_RUN и Paper достаточно решения владельца в текущем рабочем интерфейсе с обязательной записью отдельного versioned decision record. Запись содержит decision ID/version, выбранный вариант, owner reference, timestamp, точный scope, SHA-256 утверждённых `spec`, `acceptance` и применимых governance policies, hash канонического payload самой записи и явный `DENY_REAL_ORDERS`. Изменение любого связанного байта делает запись неприменимой: решение не переписывают задним числом, а выпускают новую версию.

Level A подтверждает только заранее определённые правила или некапитальный scope. Он не является доказательством качества стратегии и не может задним числом утверждать результаты, менять threshold/benchmark после просмотра данных, объявлять уже просмотренное окно новым holdout, отменять preregistration, evidence expiry/drift gate либо самостоятельно повышать lifecycle stage.

**Уровень B — решения о реальных деньгах.** Подключение реального счета/credential, Pilot, Production, новый real venue/instrument, повышение hard cap, изменение leverage/margin, перевод между реальными books и distribution требуют одновременно:

1. криптографической подписи одного canonical owner decision manifest;
2. отдельного второго подтверждения того же payload и hash через независимый подтверждающий механизм.

Оба подтверждения привязаны к одному `manifest_id`, payload hash, monotonic sequence, scope, limits и сроку действия. Второй механизм обязан иметь отдельный trust root и отдельную failure domain: два клика, сообщения или токена одной сессии/ключа/процесса не являются двумя независимыми факторами. Подтверждение другого текста, старой версии либо только одного фактора дает `DENY`. Некапитальный decision record нельзя повысить до real-capital manifest копированием, переименованием или добавлением поля.

Точный trust root, алгоритм подписи, носитель ключа, canonicalization и независимый второй канал будут определены в `PM-DEC-007`. До его принятия и реализации verifier любой Level-B manifest имеет `eligible_for_authorization=false`.

`PM-REQ-040`: Level-A approval применяется только к Development/Research/Replay/DRY_RUN/Paper и никогда не является evidence личности для real-capital action.

`PM-REQ-041`: Level-B action требует успешной проверки криптографической подписи и второго независимого подтверждения одного canonical payload; отсутствие, несовпадение, replay, expiry или revocation любого компонента дают `DENY`.

`PM-REQ-042`: Level-A approval не может ратифицировать результаты post hoc, изменять preregistered protocol/threshold/benchmark после просмотра evaluation data, переиспользовать просмотренный holdout, отменять evidence expiry/drift/quality gate либо самостоятельно разрешать stage promotion.

### 5.3. Текущее состояние

| Scope | Целевой статус | Эффективный статус сейчас | Основание |
|---|---|---|---|
| Bitget, USDT futures, BTCUSDT | `TARGET` | `ACTIVE` только для разработки, DRY_RUN/Paper | `bitget-btc-v1` и TB-001 |
| Scalping / intraday | `TARGET` | `ACTIVE` только в текущем Phase-1 scope | Owner-locked 15/85 policy |
| MOEX | `TARGET` | `FUTURE/BLOCKED` | Нет отдельной policy, ТЗ и owner manifest |
| Swing / medium-term | `TARGET` | `FUTURE/BLOCKED` | Нет отдельной стратегии и policy |
| Гибридный аллокатор | `TARGET` | `SHADOW_ONLY` | Нет права записи реальных лимитов |
| `PILOT_LIMITED_LIVE` | `TARGET` | `BLOCKED` | Нет aggregate hard caps, topology и owner manifest |
| `PRODUCTION_LIVE` | `TARGET` | `BLOCKED` | Нет Pilot evidence и отдельного решения |
| Live trading | — | `false` | Owner-locked governance baseline |

`PM-REQ-003`: новое venue, instrument, account, capital book, horizon, strategy или bot не наследуют разрешение по сходству названия либо базового актива.

`PM-REQ-004`: значения Phase 1 не копируются в мандат как второй редактируемый источник истины; active overlay ссылается на точные `policy_id`, version и hash.

## 6. Периметр портфеля и NAV

### 6.1. Определение периметра

Портфельный NAV должен вычисляться только по явному перечню включенных юридических счетов, субсчетов, кошельков, активов, обязательств и книг капитала. Актив не входит в управляемый капитал только потому, что принадлежит владельцу или технически виден системе.

Для каждого элемента периметра фиксируются:

- `perimeter_item_id`;
- legal owner/account reference без секретов;
- venue/broker/custodian;
- capital book;
- native currency и valuation method;
- включение в reporting NAV, risk NAV и stressed liquidation NAV;
- обязательства и ограничения доступности;
- effective timestamp и статус качества данных.

`PM-REQ-005`: точный NAV perimeter является owner decision `PM-DEC-004`. До решения консолидированный NAV имеет статус `INDICATIVE`, не разрешает капитал и выплаты.

### 6.2. Три вида NAV

1. **Reporting NAV** — сверенная официальная оценка для отчетности.
2. **Risk NAV** — консервативная оперативная база для риск-решений.
3. **Stressed liquidation NAV** — оценка после haircuts, exit costs, gap, depeg и доступности ликвидности.

Stale, disputed, estimated или unreconciled стоимость не может увеличивать risk capacity, distributable profit либо apparent benchmark outperformance.

## 7. Учет результата в RUB

RUB является базовой валютой консолидации, но не предписывает хранить или конвертировать все активы в RUB. Параллельно сохраняется нативный учет каждого счета и инструмента.

Для USDT-контура базовая цепочка:

`V_RUB = V_USDT × Q_USDT/USD × Q_USD/RUB`.

Отдельно отражаются:

- constant-FX strategy result;
- counterfactual/decision PnL;
- execution shortfall;
- booked PnL по подтвержденным fills;
- fees, funding, borrow, налоги и другие денежные потоки;
- stablecoin basis/depeg;
- FX translation;
- attribution residual.

Применяется единая знаковая конвенция: прибыль и входящий инструментальный cash flow положительны; убыток, cost и исходящий cash flow отрицательны. Для каждой нативной валюты:

`BookedPreCostPnL = DecisionPnL - ImplementationShortfall`,

где положительный `ImplementationShortfall` означает ухудшение относительно заранее замороженной reference price. Затем:

`NetNativeResult = BookedPreCostPnL + InstrumentCashFlows + ExplicitCosts`,

где комиссии, funding/borrow и налоги входят ровно в один заранее определенный компонент. Если они уже включены в booked cash ledger, повторное вычитание запрещено.

Для консолидации:

`ΔNAV_RUB - ExternalFlows_RUB = ConstantFXNetResult_RUB + FXTranslation_RUB + StablecoinBasis_RUB + AttributionResidual_RUB`.

Методика фиксирует порядок последовательного attribution, поэтому FX/stablecoin cross-term всегда попадает в один определенный компонент. `AttributionResidual` рассчитывается автоматически как разность сторон identity, не вводится вручную, классифицируется по причине и не может использоваться как балансирующая строка. Превышение утвержденной абсолютной или относительной tolerance делает отчет и evidence недействительными.

`PM-REQ-006`: изменение NAV за вычетом внешних cash flows должно сверяться с суммой торгового результата, инструментальных cash flows, издержек, FX/stablecoin effects и residual.

`PM-REQ-007`: spread/slippage нельзя одновременно включить в fill и повторно вычесть как расход.

`PM-REQ-008`: финансовые расчеты используют decimal/fixed-point. Каждое значение содержит currency, unit, scope, time horizon, valuation timestamp и источник.

`PM-REQ-031`: accounting profile должен версионировать reference-price rule, inclusion каждого cost/cash-flow, FX attribution order, rounding и residual tolerance; отсутствие профиля блокирует финансово значимую отчетность.

## 8. Доходность и опыт владельца

### 8.1. Обязательные показатели

- RUB time-weighted return (`TWR`) как показатель инвестиционного процесса, очищенный от внешних вводов/выводов;
- money-weighted return (`MWR/XIRR`) как отдельный показатель опыта владельца;
- геометрическая/log return и итоговый net PnL;
- rolling/subperiod результаты на заранее определенных интервалах;
- excess return относительно замороженного benchmark;
- вклад стратегии в портфельный результат и риск;
- drawdown depth, duration, time under water и recovery;
- uncertainty interval и устойчивость по режимам.

Sharpe, Sortino, win rate и profit factor могут быть диагностическими метриками, но не являются единственным admission/allocation gate.

`PM-REQ-009`: внешний ввод RUB увеличивает NAV, но не создает TWR или strategy alpha.

`PM-REQ-010`: годовые показатели, вычисленные из короткого окна, маркируются как экстраполяция и не применяются как самостоятельный gate.

`PM-REQ-032`: до расчета TWR фиксируются valuation subperiods, timing intraday flows, linking formula, precision, zero/negative NAV и stale-valuation behavior. Для XIRR фиксируются day-count, timestamp precision, numerical method, root-selection и статусы `UNDEFINED_NO_ROOT`/`UNDEFINED_MULTIPLE_ROOTS`. Внутренний transfer между книгами является внешним потоком книги, но не консолидированного портфеля.

## 9. Система бенчмарков

Используется не один универсальный benchmark, а иерархия:

1. **Capital-preservation benchmark** — owner-approved RUB cash/cash-equivalent opportunity cost.
2. **Policy portfolio benchmark** — заранее замороженная композитная экспозиция только из разрешенных рынков.
3. **Strategy economic benchmark** — сопоставимый по риску и горизонту baseline: no-trade/always-flat, passive или иное заранее утвержденное простое правило.
4. **Execution benchmark** — замороженная reference price для implementation shortfall.

Для TB-001 `always-flat/no-trade` обязателен как safety baseline. BTC buy-and-hold может быть вторичным аналитическим сравнением, но не считается risk-equivalent long/short futures benchmark.

`PM-REQ-011`: benchmark, веса, источники, cost/tax treatment, as-of rule и rebalancing convention фиксируются до начала evidence window.

`PM-REQ-012`: ретроспективная смена benchmark делает comparative evidence этого окна недействительным; старый результат не удаляется.

`PM-REQ-033`: machine-readable benchmark registry содержит ID/version/type, scope/purpose, instruments/weights, source/data hashes, costs/taxes, as-of/rebalancing/reference-price rules, freeze timestamp, evidence-window ID, benchmark hash и supersession link.

## 10. Портфельная панель риска

Численные hard caps задает только владелец в отдельной policy. Мандат требует, чтобы до реального scope были определены минимум:

- loss и drawdown caps на уровнях setup, bot, strategy family, account, venue и portfolio;
- Expected Shortfall с зафиксированными horizon/confidence/method;
- historical и hypothetical stress loss;
- gross, net и contingent exposure до разрешенного netting;
- notional, leverage, margin usage и liquidation distance;
- gap loss и risk of ruin с неопределенностью модели;
- concentration по instrument, underlying, factor, sector, currency, venue, broker, custodian, collateral, stablecoin, settlement system, data source и strategy family;
- normal/stressed correlation, drawdown concurrence и component/marginal risk contribution;
- counterparty, custody, settlement и operational failure exposure.

`PM-REQ-013`: действующие setup limits нельзя механически умножить на количество позиций и объявить портфельным лимитом.

`PM-REQ-014`: отсутствие aggregate hard cap не означает бесконечный лимит; соответствующий real-capital transition возвращает `DENY`.

## 11. Гибридная иерархия лимитов

Применяется порядок:

> owner hard cap → protection state → adaptive only-down caps → portfolio allocator → strategy/bot cap → order intent.

Лимиты представлены типизированным вектором:

`L[risk_metric, scope, horizon, unit, currency, valuation_basis]`.

`min()` применяется только среди верхних границ с одинаковым ключом и совместимыми единицами. Разнородные ограничения — loss, notional, leverage, margin, liquidation distance, liquidity, concentration и stress — применяются к intent и портфельному состоянию логическим `AND`. Missing key или невозможность однозначного преобразования единиц дают `DENY`.

`PM-REQ-015`: ни один adaptive/allocator/bot input не может увеличить hard cap.

`PM-REQ-016`: missing, stale, contradictory или uncertain input уменьшает/замораживает риск либо дает `DENY`; возврат к максимуму запрещен.

`PM-REQ-017`: если adaptive recommendation несовместима с owner-locked minimum/other policy, intent отклоняется или обнуляется; система не изменяет policy самостоятельно.

`PM-REQ-018`: восстановление после `PROTECT/EMERGENCY` требует hysteresis, cooldown, повторного evidence и предусмотренного owner gate.

`PM-REQ-034`: child reservations по positions, open/cancel-pending/conditional orders и одновременно конкурирующим intents атомарно агрегируются в parent account/venue/portfolio limits. Low net exposure не уменьшает gross/contingent checks.

До отдельного решения центральный аллокатор работает только в `SHADOW_ONLY` и не имеет write-capability к лимитам, торговым правам и переводам капитала.

## 12. Ликвидность и capacity

Capacity задается кривой по tested size tiers, а не одним числом. Для каждого tier показываются conservative/base/adverse execution scenarios.

Обязательны:

- spread и executable depth;
- participation rate;
- market impact и slippage;
- queue/partial-fill/cancel uncertainty;
- exit horizon в normal, adverse и venue-impaired состояниях;
- cost/risk неисполненного protective exit;
- margin liquidity coverage;
- агрегированный спрос всех коррелированных ботов на один liquidity pool;
- максимальный размер, при котором conservative net edge остается положительным и hard constraints соблюдены.

`PM-REQ-019`: линейная экстраполяция за пределы проверенных size tiers запрещена.

`PM-REQ-020`: low net exposure после netting не скрывает gross и contingent exposure.

`PM-REQ-035`: capacity tier связан с order-size distribution, participation, market-data sample, fill-model version/evidence level, uncertainty interval, shared liquidity pool, stress exit horizon и expiry. Положительная точечная оценка недостаточна: tier проходит только owner-approved economically meaningful hurdle и uncertainty criterion. Первый failing/untested tier и все более крупные tiers недоступны.

## 13. Книги капитала

### 13.1. Назначение книг

| Книга | Назначение | Реальные торговые полномочия сейчас |
|---|---|---|
| `RESEARCH_PAPER` | Симуляция и evidence | Нет |
| `PILOT` | Отдельный ограниченный реальный капитал | `BLOCKED` |
| `PRODUCTION` | Допущенные стратегии | `BLOCKED` |
| `OPERATIONAL_MARGIN_RESERVE` | Утвержденные операционные/маржинальные обязательства | Не является свободным капиталом стратегии |
| `PROTECTED_RESERVE` | Капитал вне полномочий ботов | Нет |
| `DISTRIBUTION_PAYABLE` | Settled/realized/reconciled cash, признанный к выплате | Не используется для покрытия торговых убытков |

`PM-REQ-021`: отсутствие явно разрешенного transfer route означает запрет.

`PM-REQ-022`: перевод между книгами не является PnL и не меняет общий NAV.

`PM-REQ-023`: unrealized, unsettled, stale, disputed, encumbered или unreconciled amount не попадает в `DISTRIBUTION_PAYABLE`.

`PM-REQ-024`: виртуальная книга не доказывает физическую изоляцию. До Pilot требуется account topology matrix: `book → venue/broker → legal account → subaccount → margin pool → bot/strategy → credential scope`.

Machine accounting profile определяет для каждой книги включение в reporting/risk/stressed NAV и TWR denominator, double-entry проводки и статус ограничения средств. `DISTRIBUTION_PAYABLE` отдельно классифицируется как internal reservation либо recognized liability; одна сумма не может одновременно учитываться как свободный капитал, резерв и payable.

## 14. Распределение прибыли

Выплата возможна только после:

1. полного PnL/NAV reconciliation;
2. settlement денежных потоков;
3. восстановления обязательных резервов;
4. выполнения owner-approved high-water mark;
5. отсутствия stale/disputed valuation и неизвестных обязательств;
6. расчета применимых налоговых/операционных резервов;
7. отдельного owner-approved transfer decision.

Distribution waterfall, payout share, frequency и suspension rules являются решением `PM-DEC-010`. До его утверждения распределяемая сумма равна нулю вне зависимости от Paper PnL.

## 15. Полномочия

| Actor | Может | Не может |
|---|---|---|
| `OWNER` | Утверждать/отзывать scope, hard caps, real stage, transfers и distribution | Отменять non-waivable safety invariants даже явным принятием риска |
| `INVESTMENT_COMMITTEE` | Собирать evidence и рекомендовать решение | Разрешать реальный капитал |
| `SECOND_LINE_REVIEWER` | Блокировать gate и фиксировать finding | Редактировать объект review или закрывать собственный finding |
| `RISK_SENTINEL` | Уменьшить лимит, заблокировать новые intents | Повысить лимит или перевести капитал |
| `PORTFOLIO_ALLOCATOR` | В shadow рекомендовать распределение | Менять hard caps или real books |
| `STRATEGY_BOT` | Предложить order intent в своем scope | Выдать себе лимит или permission |
| `OPERATOR` | Остановить, изолировать, запустить reconciliation | Расширить scope или повторно включить после owner gate |
| `RELEASE_VERIFIER` | Выдать `PASS/FAIL/BLOCKED` | Waive failed gate |

`PM-REQ-025`: только владелец может расширить финансовые полномочия. Автоматика может сохранить или сузить их.

Неотменяемые даже владельцем runtime-инварианты: unknown account/order/position state, незавершенная reconciliation, stale/malformed mandatory data, auth/secret failure, отсутствующая idempotency, policy/hash mismatch и невозможность доказать фактический exposure всегда означают `NO_NEW_RISK`. Владелец может принять остаточный business/model risk только после восстановления доказуемого состояния; принятие риска не превращает неизвестное состояние в известное.

## 16. Owner decision manifest

Разрешение владельца оформляется отдельным машиночитаемым manifest и содержит минимум:

- `manifest_id`, version, decision и monotonic sequence/nonce;
- `owner_identity_ref` без секретного значения;
- проверяемое approval evidence и trust root;
- `issued_at`, `effective_from`, `review_due_at`, `expires_at`;
- точный scope: stage, account, capital book, venue, market, instruments, strategy и bot;
- точные limits с units/currency/horizon;
- hashes governance policy, mandate, spec, acceptance, build и dataset, где применимо;
- canonicalization/hash algorithm;
- revocation reference, `revoked_at` и reason.

`PM-REQ-026`: отсутствие manifest, несовпадение любого hash/scope/stage/account/instrument, expiry, revocation либо неподтвержденная owner identity дают `DENY`.

`PM-REQ-027`: старый manifest нельзя применить к новой baseline, policy, build, dataset или расширенному scope.

Текущий `owner-decision-manifest.schema.json` является только `NON_AUTHORIZING_DRAFT`: он способен выразить исключительно `DENY` и не может войти в authority path. Полная ratified schema создается после owner decisions и semantic review. В будущем mandate ссылается на стабильный `manifest_id`, а manifest содержит hash mandate payload; circular content hashes запрещены. Проверка signature/trust root, monotonic sequence, bounded TTL и revocation обязательна вне JSON Schema.

## 17. Стадии и переходы

Допустимы автоматические переходы только в равное или более ограничительное состояние. Повышение стадии требует всех gates и нового owner manifest.

| Переход | Автоматически | Owner decision | Текущий статус |
|---|---:|---:|---|
| `RESEARCH → REPLAY` | После research gates | Нет | Возможен |
| `REPLAY → DRY_RUN` | После acceptance | Нет | Возможен в Phase 1 |
| `DRY_RUN → PAPER` | После acceptance/evidence freeze | Требуется по активному work item | Цель первого среза |
| `PAPER → PILOT_LIMITED_LIVE` | Никогда | Обязательно | `BLOCKED` |
| `PILOT → PRODUCTION_LIVE` | Никогда | Обязательно | `BLOCKED` |
| Любая стадия → более ограничительная | По protection policy | Для аварийного снижения не требуется | Разрешено |
| `PROTECT/EMERGENCY → восстановление` | Никогда немедленно | По утвержденному gate | `BLOCKED` до review |

Expiry, manifest mismatch, revocation, policy conflict, unknown account state или emergency переводят scope в `BLOCKED/NO_NEW_RISK`.

До `PAPER → PILOT_LIMITED_LIVE` обязательны четыре отдельные owner-locked ссылки: `entry_order_policy`, `protective_exit_policy`, `profit_taking_policy`, `emergency_liquidation_or_hedge_policy`. Они определяют trigger source, native/synthetic stop, reduce-only, stop-limit no-fill, gap, price protection, partial fill, cancel/fill race, halt, residual-exposure timeout, fallback и reconciliation. Неизвестная или неподдерживаемая venue capability дает `DENY`.

Каждый scope также ссылается по hash на отдельный versioned `venue_capability_profile`: official-document date/API version, sessions/timezone/clocks, auctions/halts/maintenance/clearing, order types/TIF/conditional/reduce-only, tick/lot/price bands, settlement/margin/borrow, corporate actions/expiry/roll, funding/mark/index, rate limits и degraded states. Профили MOEX и 24/7 crypto не взаимозаменяемы.

## 18. Evidence и запрет metric gaming

До окна оценки фиксируются:

- objective hierarchy;
- formulas и полный metric panel;
- NAV perimeter и valuation time;
- data/FX sources и stale rules;
- benchmarks и weights;
- cost/fill assumptions;
- risk horizons;
- evidence window и stopping rule;
- minimum economically meaningful result;
- multiple-testing budget и experiment registry.

Запрещено:

- выбирать лучшие dates/regimes/bots/fills/FX conversion/software baseline после результата;
- скрывать failed experiments или excluded periods;
- считать raw setups независимой выборкой при clustering/overlap;
- выдавать FX или deposit effect за strategy alpha;
- скрывать gross leverage netting-ом;
- использовать optimistic fill model как единственное основание допуска;
- повышать риск по recent PnL;
- объединять несовместимые baselines в непрерывный track record.

`PM-REQ-028`: полный experiment registry, versions, exclusions и negative results сохраняются.

`PM-REQ-029`: positive result содержит uncertainty и поправку на selection/multiple testing.

`PM-REQ-030`: evidence имеет expiry/review date и downgrade rules; expired evidence не разрешает capital increase или promotion.

`PM-REQ-036`: experiment evidence содержит заранее определенные family/test budget, unique experiment IDs включая failures, sealed cutoff/access log, setup-cluster rule, raw/cluster/effective sample, uncertainty estimator и multiple-testing correction. Missing/post-hoc method дает `BLOCKED`.

`PM-REQ-037`: каждый evidence item имеет собственные scope, dataset/build/model/benchmark hashes, observation cutoff, issue/review/expiry timestamps, drift metrics/thresholds, invalidation events, downgrade action и reviewer verdict. Evidence expiry не наследуется от срока mandate или manifest.

`PM-REQ-038`: FX valuation profile задает source hierarchy, bid/mid/ask convention для каждого NAV, as-of/calendar, stale/conflict thresholds, fallback, depeg/liquidity haircuts, cross-rate construction, rounding и missing-market behavior. До утверждения consolidated NAV остается `INDICATIVE` и недоступным для comparative admission/distribution.

## 19. Reporting contract

Каждый портфельный отчет содержит:

- mandate/policy/build/dataset identifiers и hashes;
- reporting period и valuation timestamps;
- reporting/risk/stressed NAV;
- external cash flows, TWR и MWR/XIRR;
- full PnL bridge и attribution residual;
- benchmark results и uncertainty;
- drawdown/recovery/ES/stress/risk-of-ruin panel;
- gross/net/contingent exposures и concentrations;
- liquidity/capacity и exit horizon;
- stale/disputed/unreconciled percentage;
- incidents, unknown orders, reconciliation duration и ledger gaps;
- capital-book balances и transfers;
- действующий protection state;
- unresolved findings, evidence expiry и next review date.

Пустое обязательное поле является отсутствующим evidence, а не нулем.

## 20. Управление изменениями

Каждое изменение создает новую версию, diff, decision ID и audit event. In-place mutation нормативного artifact запрещена.

Изменение цели, scope, hard cap, benchmark, NAV perimeter, authority, transfer route, stage semantics или distribution waterfall является финансово значимым и требует owner review. При неопределенности выбирается более высокий impact class.

Удаление requirement ID запрещено. Устаревшее требование получает `SUPERSEDED_BY` и остается в истории.

## 21. Известные конфликты и ограничения

| ID | Severity | Ограничение | Безопасный статус |
|---|---|---|---|
| `PM-RISK-001` | BLOCKER | Target MOEX/дополнительные горизонты шире active Phase 1 | `FUTURE/BLOCKED` |
| `PM-RISK-002` | BLOCKER | Нет owner-approved aggregate portfolio hard caps | Pilot/Production `BLOCKED` |
| `PM-RISK-003` | HIGH | Cross margin создает account-level contagion | Не заявлять физическую изоляцию; Pilot `BLOCKED` |
| `PM-RISK-004` | BLOCKER | Не определены protective/emergency order policies | Pilot `BLOCKED` |
| `PM-RISK-005` | BLOCKER | Нет owner manifest trust/verification model | Real scope `BLOCKED` |
| `PM-RISK-006` | HIGH | Не утверждены benchmark/valuation/waterfall | Comparative admission/distribution `BLOCKED` |
| `PM-RISK-007` | HIGH | TB-001 acceptance еще не покрывает все portfolio accounting/capacity gates | Paper bot result не считается полным portfolio evidence |

## 22. Решения владельца

### 22.0. Принятые решения

| ID | Решение | Эффект |
|---|---|---|
| `PM-DEC-001` | Вариант 3: `TARGET + нормативный overlay Development/Research/Replay/DRY_RUN/Paper` | Обязателен для некапитального lifecycle; real orders/Pilot/Production остаются `DENY/BLOCKED` |
| `PM-DEC-002` | Вариант 3: versioned record для некапитальных решений; cryptographic signature + independent second confirmation для real-capital actions | Level A не дает real authority; Level B `DENY` до `PM-DEC-007` и verifier |

### 22.1. Блокируют ратификацию active machine mandate

| ID | Решение | Fail-closed default |
|---|---|---|
| `PM-DEC-003` | Effective/review/expiry/revocation/supersession rules | Мандат не разрешает real scope |
| `PM-DEC-004` | Точный NAV perimeter | Consolidated NAV `INDICATIVE` |
| `PM-DEC-005` | Численные aggregate hard caps и резервы | Pilot/Production `BLOCKED` |
| `PM-DEC-006` | Финальная authority matrix и delegation boundaries | Расширение полномочий только вручную владельцем |
| `PM-DEC-007` | Canonicalization/hash/signature/manifest verification | Любой manifest `DENY` |
| `PM-DEC-008` | Fail-closed semantics всех stages/scopes | Самый ограничительный статус |
| `PM-DEC-009` | Binding benchmark hierarchy и comparative-admission rules | Admission по excess return `BLOCKED` |
| `PM-DEC-010` | Distribution waterfall, HWM, reserves, taxes, payout cap/frequency/suspension/clawback и source/destination books | Distributions `BLOCKED`, payable amount zero |
| `PM-DEC-011` | Accounting profile и residual tolerance | Финансовое evidence не допускает promotion |
| `PM-DEC-012` | TWR/MWR/XIRR methodology profile | Показатели маркируются `UNRATIFIED` |
| `PM-DEC-013` | FX/stablecoin valuation profile | Consolidated NAV `INDICATIVE` |
| `PM-DEC-014` | Experiment/effective-sample/multiple-testing policy | Comparative strategy admission `BLOCKED` |
| `PM-DEC-015` | Capacity economically meaningful hurdle и uncertainty criterion | Real size tier отсутствует |

### 22.2. Допускается отложить при сохранении scope BLOCKED/FUTURE/SHADOW_ONLY

- MOEX universe, boards/regimes и instruments — до MOEX ТЗ;
- account/subaccount/margin/credential topology — до Pilot;
- protective/profit/emergency execution — до Pilot;
- adaptive formulas, windows, floors, hysteresis/cooldown — до write-enabled allocator;
- allocation corridors четырех горизонтов — до реального капитала;
- FX sources, stale thresholds и haircuts — до консолидированной финансово значимой отчетности;
- Paper/Strategy Evidence numeric thresholds — до `Paper → Pilot`;
- protection-state numeric thresholds и action matrix — до Pilot;
- legal/tax/broker/custody/settlement perimeter — до соответствующего real venue;
- intent conflict/netting/hedging policy — до одновременной активации ботов на одном underlying.

## 23. Acceptance contract

Машиночитаемые критерии находятся в `acceptance.toml`. Каждый `PM-AC-*` связан с требованиями и рисками. Для текущей редакции прохождение document gates означает только готовность продолжать проектирование; оно не означает разрешение Pilot/live.

## 24. Явные предположения

- `PM-ASM-001`: документ действует как нормативный overlay только для Development/Research/Replay/DRY_RUN/Paper; реальное разрешение из этого не следует.
- `PM-ASM-002`: Phase 1 ограничен DRY_RUN/Paper и не требует real order submission.
- `PM-ASM-003`: RUB — валюта консолидации, а не обязательная валюта хранения.
- `PM-ASM-004`: существующие численные значения Phase 1 сохраняются без изменения только в собственном scope.
- `PM-ASM-005`: шесть книг пока являются нормативной моделью; physical topology не доказана.
- `PM-ASM-006`: юридическая, налоговая и регуляторная применимость будет проверена отдельно до реального капитала.

## 25. Не-цели этой главы

Глава не:

- выбирает конкретные торговые сигналы;
- обещает прибыль или доходность;
- утверждает численные aggregate limits;
- разрешает MOEX, новый символ, счет или credential;
- определяет все детали execution и fill model;
- разрешает перевод либо вывод средств;
- включает live trading.
