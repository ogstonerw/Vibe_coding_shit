# PM-001 — Реестр независимого review

Дата: 17.07.2026  
Исходная редакция: 0.1  
Исправленная редакция: 0.4  
Объект фиксации: `TARGET + ACTIVE NON-CAPITAL OVERLAY / REAL CAPITAL BLOCKED`

## Состав проверки

1. `institutional_portfolio_reviewer` — CIO/CRO и совокупный риск.
2. `quant_methodology_reviewer` — accounting, evidence и model risk.
3. `market_microstructure_reviewer` — execution, account topology, venue и capacity.

Review выполнялся read-only. Исправления вносил один root writer. После исправлений затронутые findings были повторно проверены.

## Первичный вердикт

Все три reviewer-а выдали `PASS WITH REQUIRED CHANGES` для продолжения разработки и `BLOCKED` для machine ratification/реального капитала.

Ключевые проблемы исходной редакции:

- draft schema могла описать противоречивую комбинацию локального `ACTIVE` и real-capital полей;
- owner manifest schema могла выглядеть авторизующей без полного verifier contract;
- scalar `min()` смешивал несовместимые единицы риска;
- формулировка полномочий допускала трактовку, что владелец может отменить unknown-state gate;
- PnL identity не определяла точную знаковую конвенцию и ограничение residual;
- TWR/MWR, benchmark, multiple testing, evidence expiry, FX и capacity были недостаточно детерминированы;
- account/margin/credential topology и четыре execution policies не были отдельными machine gates;
- `ACTIVE/PAPER` не имел явного технического запрета real adapter;
- отсутствовала автоматическая проверка уникальности traceability IDs.

## Disposition

| Область | Исправление в 0.2 |
|---|---|
| Draft authority | `mandate.schema.json` и example принудительно задают `BLOCKED`, `DENY`, no-real credential, no endpoint access и zero real authority |
| Owner manifest | Текущая schema явно `NON_AUTHORIZING_DRAFT`, `decision=DENY`, `eligible_for_authorization=false`; ratified schema отложена до owner decisions |
| Risk limits | Введен типизированный вектор `L[metric,scope,horizon,unit,currency,basis]`; heterogeneous constraints применяются через `AND` |
| Runtime safety | Unknown state, reconciliation, stale mandatory data, auth, idempotency и policy/hash mismatch объявлены non-waivable |
| Accounting | Зафиксированы signed identities, automatic residual и обязательный accounting profile/tolerance |
| Return metrics | Добавлены детерминированные TWR/MWR/XIRR methodology requirements и undefined states |
| Evidence | Добавлены benchmark registry, experiment budget, clusters/effective sample, independent expiry/drift и mutation tests |
| FX | Добавлен versioned FX/stablecoin valuation profile; до него consolidated NAV только `INDICATIVE` |
| Capacity | Admission требует conservative hurdle с uncertainty, tested tiers, shared-pool demand и expiry |
| Execution | Добавлены отдельные entry/protective/profit/emergency policies и hash-bound venue capability profile |
| Topology | Добавлены account/margin/credential topology, book uniqueness и contagion gates |
| Traceability | Self-check проверяет уникальность task/requirement/decision/acceptance IDs и полное покрытие |

## Финальный вердикт

| Reviewer | Non-authorizing chapter freeze | Active mandate / real capital |
|---|---|---|
| Institutional CIO/CRO | `PASS` | `BLOCKED` |
| Quant methodology | `PASS` | `BLOCKED` |
| Market microstructure | `PASS` | `BLOCKED` |

Незакрытых `BLOCKER/HIGH` для фиксации версии 0.2 как неавторизующего черновика нет.

## Безопасно отложенные gates

До ratified machine mandate и тем более Pilot остаются обязательными:

- решения владельца `PM-DEC-001…PM-DEC-015`;
- полная ratified mandate/owner-manifest schema;
- semantic validator, persistent registry, signature/revocation verifier и authorization evaluator;
- численные typed aggregate hard caps и reserves;
- physical account/margin/credential topology;
- четыре owner-approved execution policies;
- отдельные crypto/MOEX venue profiles;
- accounting/TWR/MWR/FX/benchmark/statistical/capacity profiles;
- реализация всех применимых `PM-AC-*` и повторный evidence review.

Текущие governance policies не изменялись; live trading остается выключенным.

## Дополнение версии 0.3 — PM-DEC-001

Владелец выбрал вариант 3: глава обязательна для Development, Research, Replay, DRY_RUN и Paper. Решение записано в `decisions/PM-DEC-001.toml` и связано с `PM-REQ-039`/`PM-AC-037`.

После изменения проведен отдельный targeted review:

| Reviewer | Вердикт | Подтвержденная граница |
|---|---|---|
| Institutional CIO/CRO | `PASS` | Overlay не меняет policies и не предоставляет real capital authority |
| Quant methodology | `PASS` | Research/Paper evidence и preregistration обязательны, но не равны Pilot/live |
| Market microstructure | `PASS` | Только simulator/non-real boundaries, `RESEARCH_PAPER`, no credential и zero endpoint access |

Незакрытых `BLOCKER/HIGH` для `ACTIVE_NON_CAPITAL` overlay нет. `PM-DEC-002…PM-DEC-015`, ratified schemas/verifier, Pilot, Production и live остаются `BLOCKED`.

## Дополнение версии 0.4 — PM-DEC-002

Владелец выбрал вариант 3: Level A для некапитальных решений и Level B для любых действий с реальным капиталом. Level B требует криптографическую подпись и независимое второе подтверждение одного canonical payload; до принятия `PM-DEC-007` он неизменно возвращает `DENY`.

Первичный targeted review обнаружил три класса `HIGH`:

- Level-A record не был hash-bound к точным версиям `spec`, `acceptance`, policies и decision payload;
- Level A мог быть неверно истолкован как post-hoc одобрение результатов или waiver research/evidence gates;
- factor-binding допускал одинаково отсутствующие поля, не контролировал полный closed set финансовых действий и persistent sequence freshness.

Исправления редакции 0.4:

- decision record содержит точный duplicate-free набор SHA-256 четырёх утверждённых artifacts и hash полного canonical decision payload;
- изменение любого artifact, payload или обязательного hash делает запись неприменимой;
- post-hoc result ratification, benchmark/threshold mutation, viewed-holdout reuse, drift/expiry waiver и approval-only promotion явно запрещены;
- обязательны непустые и типизированные `manifest_id`, payload/scope/limits digests, положительный sequence и bounded UTC expiry;
- два фактора должны иметь разные trust roots и failure domains;
- missing/malformed/mismatch, replay/non-monotonic sequence, expiry, revocation и сужение closed action set дают `DENY`;
- даже валидная по форме пара не авторизует капитал до отдельного `PM-DEC-007` и реализации trusted verifier/state registry.

| Reviewer | Повторный вердикт | Подтверждённая граница |
|---|---|---|
| Institutional CIO/CRO | `PASS` | Artifact/payload hash binding и mutation detection |
| Quant methodology | `PASS` | Нет post-hoc evidence waiver; missing/malformed/replay fixtures дают `DENY` |
| Security | `PASS` | Closed action set, factor independence, sequence freshness и fail-closed до `PM-DEC-007` |

Незакрытых `BLOCKER/HIGH` для фиксации `PM-DEC-002` как некапитального governance-решения нет. Ratified Level-B schema/verifier, Pilot, Production и любой real-capital action остаются `BLOCKED`.
